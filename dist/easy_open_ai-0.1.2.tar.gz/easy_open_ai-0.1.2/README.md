# _Welcome to my OpenAI Playground!_

_STILL ACTIVELY DEVELOPING_

## How to play

- `pip install easy-open-ai`
- make `.env` with `OPENAI_API_KEY=`
- enjoy !
  - `get_picture(text, save=True)`
  - `correct_grammar(text)`
  - `get_answer(question)`
  - `get_answer_with_instruction(question,instruction`
  - `translate_text_to_Ukrainian(text)`
  - `get_n_pictures(text, n=3)`
